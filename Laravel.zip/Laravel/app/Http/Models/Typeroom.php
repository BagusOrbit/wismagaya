<?php namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Typeroom extends Model {
    protected $table = "typeroom";
    public $timestamps = false;
    protected $primaryKey = 'idtyperoom';
   
}