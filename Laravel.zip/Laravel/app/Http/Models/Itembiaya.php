<?php namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Itembiaya extends Model {
    protected $table = "itembiaya";
    public $timestamps = false;
    protected $primaryKey = 'id';
   
}