<?php namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Inap extends Model {
    protected $table = "menginap";
    public $timestamps = false;
    protected $primaryKey = 'id';
   
}