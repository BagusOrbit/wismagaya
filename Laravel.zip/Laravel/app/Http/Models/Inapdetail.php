<?php namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Inapdetail extends Model {
    protected $table = "menginapdetail";
    public $timestamps = false;
    protected $primaryKey = 'idpemesanandetail';
   
}