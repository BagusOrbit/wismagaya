<?php namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Bayarkamar extends Model {
    protected $table = "bayarkamar";
    public $timestamps = false;
    protected $primaryKey = 'id';
   
}