<?php namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Inaptambahan extends Model {
    protected $table = "menginapdetailtambahan";
    public $timestamps = false;
    protected $primaryKey = 'id';
   
}