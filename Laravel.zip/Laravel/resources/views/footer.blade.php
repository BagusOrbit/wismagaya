<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        
    </div>
    <!-- Default to the left -->
    <strong>Copyright © 2016 <a href="#">WismaGAYA</a>.</strong>
</footer>