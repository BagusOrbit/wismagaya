<div class="box box-primary">
    <div class="box-body">
    <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="form-group">
            <?php echo Form::label('noroom', 'Nomor Kamar', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('noroom', null, ['class' => 'form-control', 'placeholder' => 'Nomor Kamar']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('namaroom', 'Nama Kamar', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('namaroom',null, ['class' => 'form-control', 'placeholder' => 'namakamar']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('idtyperoom', 'Tipe Kamar', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::select('idtyperoom', $typeroom,null, ['class' => 'form-control', 'placeholder' => 'Tipe Kamar','id' => 'state']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('harga', 'Harga', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('harga',null, ['class' => 'form-control', 'placeholder' => 'Harga']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('fasilitas', 'Fasilitas', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::textarea('fasilitas', null, ['class' => 'form-control', 'placeholder' => 'Fasilitas']); ?>

            </div>
        </div>
        <div class="form-group">
            <div class="col-md-offset-2 col-md-4">
                <button class="btn btn-flat btn-primary" type="submit">Simpan</button>
                <a href="<?php echo e(url('/room')); ?>" class="btn btn-flat btn-default">Batal</a>
            </div>
        </div>
    </div>
</div>
