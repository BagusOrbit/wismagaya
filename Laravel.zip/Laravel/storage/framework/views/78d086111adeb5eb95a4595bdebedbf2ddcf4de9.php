<?php $__env->startSection('title'); ?>
<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
Data Kamar
    <div class="pull-right">
        <!-- <button class="btn btn-flat btn-sm btn-primary" id="load-data-asli"><i class="glyphicon glyphicon-leaf"></i> Lihat Data Asli</button> -->
        <a href="<?php echo e(url('room/tambah')); ?>" class="btn btn-flat btn-sm btn-primary"><i class="fa fa-plus"></i> Tambah Kamar</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
        
        <div class="box-body table-responsive no-padding">
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    
                    <th>No</th>
                    <th>No Kamar / Room</th>
                    <th>Nama Kamar / Room</th>
                    <th>Tipe Kamar</th>
                    <th>Fasilitas</th>
                    <th>Harga</th>
                    <th style="min-width: 150px;width: 150px"></th>
                </tr>
                <?php $no = 1; ?>
                <?php $__empty_1 = true; foreach($data as $key => $u): $__empty_1 = false; ?>
                    <tr>
                        
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->noroom; ?></td>
                        <td><?php echo $u->namaroom; ?></td>
                        <td><?php echo $u->present()->idtyperoom; ?></td>
                        <td><?php echo $u->fasilitas; ?></td>
                        <td><?php echo $u->harga; ?></td>
                        <td>
                            <a href="<?php echo e(url('room/edit', ['id' => $u->idroom])); ?>" class="btn btn-flat btn-sm btn-primary"><i class="fa fa-edit"></i> Edit</a>
                            <a href="<?php echo e(url('room/hapus', ['id' => $u->idroom])); ?>" class="btn btn-flat btn-sm btn-warning"><i class="fa fa-remove"></i> Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="9">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>