<?php $__env->startSection('title'); ?>
    Tambah Biaya - Biaya
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['class' => 'form-horizontal']); ?>

    <?php echo $__env->make('transaksi.biaya.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>