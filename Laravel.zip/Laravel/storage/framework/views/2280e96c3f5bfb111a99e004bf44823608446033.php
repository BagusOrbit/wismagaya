<?php $__env->startSection('title'); ?>
<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    Detail Pemesanan Kamar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo Form::model($reservasi,['class' => 'form-horizontal']); ?>

    <?php echo $__env->make('transaksi.inapkamar.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

    	var total = $('#totalakhir').val();

    	//pajak nominal
    	$('#pajaknominal').on('input',function(e){
	     var pajak = $('#pajaknominal').val();
	     var pot = $('#potongannominal').val();
	     var biaya = $('#biayalain').val();
	     var totalakhir = parseInt(biaya,10) + parseInt(total,10) + parseInt(pajak,10) - parseInt(pot,10);
	     $('#totalsemua').val(totalakhir);
	    });
	    $('#biayalain').on('input',function(e){
	    //biaya lain
        var pajak = $('#pajaknominal').val();
	     var pot = $('#potongannominal').val();
	     var biaya = $('#biayalain').val();
	     var totalakhir = parseInt(biaya,10) + parseInt(total,10) + parseInt(pajak,10) - parseInt(pot,10);
	     $('#totalsemua').val(totalakhir);
	    });
	    $('#potongannominal').on('input',function(e){
		//Potongan Nominal
		var pajakbaru = (total - $('#potongannominal').val()) * 0.1;
		$('#pajaknominal').val(pajakbaru);
        var pajak = $('#pajaknominal').val();
	     var pot = $('#potongannominal').val();
	     var biaya = $('#biayalain').val();

	     var totalakhir = parseInt(biaya,10) + parseInt(total,10) + parseInt(pajakbaru,10) - parseInt(pot,10);
	     $('#totalsemua').val(totalakhir);
	    });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>