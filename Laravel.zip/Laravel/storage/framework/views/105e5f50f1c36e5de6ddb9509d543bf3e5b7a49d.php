<?php $__env->startSection('title'); ?> Hapus Data Reservasi Kamar@endsection

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo Form::model($reservasi, ['class' => 'form-horizontal']); ?>

            <div class="box box-solid box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Apakah yakin menghapus data reservasi kamar?</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <?php echo Form::label('nopesanan', 'No Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->nopesanan); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('namapesanan', 'Nama Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->namapesanan); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('noidentitas', 'KTP/SIM', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->noidentitas); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('alamat', 'alamat', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->alamat); ?>

                        </div>
                    </div>

    <div class="box">
        
        <div class="box-body table-responsive no-padding">
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    <th>No</th>
                    <th>Nota</th>
                    <th>No Kamar</th>
                    <th>Tanggal Cek In</th>
                    <th>Tgl Cek Out</th>
                    <th>Jumlah (Hari)</th>
                    
                </tr>
                <?php $no = 1 ; ?>
                <?php $__empty_1 = true; foreach($reservasidetail as $key => $u): $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->nota; ?></td>
                        <td><?php echo $u->noroom; ?></td>
                        <td><?php echo $u->tglcheckin; ?></td>
                        <td><?php echo $u->tglcheckout; ?></td>
                        <td><?php echo $u->Jumlahhari; ?></td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="9">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
                    
                    <div class="form-group">
                        <div class="col-md-offset-2 col-md-10">
                            <button class="btn btn-flat btn-primary" type="submit">Hapus</button>
                            <a href="<?php echo e(url('/reservasi')); ?>" class="btn btn-flat btn-default">Batal</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>