<?php $__env->startSection('title'); ?> Cek Out Kamar / Menginap@endsection

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo Form::model($inapdetail, ['class' => 'form-horizontal']); ?>

            <div class="box box-solid box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Apakah yakin Cek Out kamar?</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <?php echo Form::label('tglcheckin', 'Tgl Cek In', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($inapdetail->tglcheckin); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('tglcheckout', 'Tgl Cek Out', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($inapdetail->tglcheckout); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('noroom', 'No Kamar', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($inapdetail->noroom); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('Jumlahhari', 'Jumlah Hari', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($inapdetail->Jumlahhari); ?>

                        </div>
                    </div>
                    <!-- <div class="form-group">
                        <?php echo Form::label('tglcheckin', 'Tgl Cek In', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-4">
                            <?php echo Form::text('tglcheckin', $inapdetail->tglcheckin, ['class' => 'form-control datepicker','disabled'=>'disabled',]); ?>

                        </div>
                        <?php echo Form::label('tglcheckout', 'Tgl Cek Out', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-4">
                            <?php echo Form::text('tglcheckout', $inapdetail->tglcheckout, ['class' => 'form-control datepicker', 'disabled' => 'disabled',]); ?>

                        </div>
                    </div>
        
                    <div class="form-group">
                        <?php echo Form::label('noroom', 'No Kamar', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-4">
                            <?php echo Form::text('noroom', $inapdetail->noroom, ['class' => 'form-control', 'placeholder' => 'Kamar','id' => 'state']); ?>

                        </div>
                        <?php echo Form::label('Jumlahhari', 'Hari', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-4">
                            <?php echo Form::text('Jumlahhari',$inapdetail->Jumlahhari, ['class' => 'form-control', 'placeholder' => 'Jumlah Hari']); ?>

                        </div>
                    
                    </div> -->
                    
                    <div class="form-group">
                        <div class="col-md-offset-2 col-md-10">
                            <button class="btn btn-flat btn-primary" type="submit">Cek Out</button>
                            <a href="<?php echo e(url('/inapkamar/bayar',$inap->id)); ?>" class="btn btn-flat btn-default">Batal</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>