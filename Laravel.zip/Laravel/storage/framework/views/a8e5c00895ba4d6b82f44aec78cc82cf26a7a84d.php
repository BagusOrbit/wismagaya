<?php $__env->startSection('title'); ?> Hapus Data Detail Reservasi Kamar@endsection

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo Form::model($reservasidetail, ['class' => 'form-horizontal']); ?>

            <div class="box box-solid box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Apakah yakin menghapus data detail reservasi kamar?</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <?php echo Form::label('nopesanan', 'No Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasidetail->nopesanan); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('noroom', 'No Kamar', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasidetail->noroom); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('tglcheckin', 'Tgl Cek In', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasidetail->tglcheckin); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('tglcheckout', 'Tgl Cek Out', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasidetail->tglcheckout); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('Jumlahhari', 'Jumlah Hari', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasidetail->Jumlahhari); ?>

                        </div>
                    </div>
                    <div>
                        
                    </div>
                    <div class="form-group">
                        <div class="col-md-offset-2 col-md-10">
                            <button class="btn btn-flat btn-primary" type="submit">Hapus</button>
                            <a href="<?php echo e(url('/reservasidetail/tambah',$reservasi->id)); ?>" class="btn btn-flat btn-default">Batal</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>