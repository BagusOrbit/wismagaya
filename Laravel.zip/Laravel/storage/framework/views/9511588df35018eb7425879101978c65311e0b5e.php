<?php $__env->startSection('title'); ?>
<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
Data Menginap
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
        <!-- <div class="box-header">
            <div class="form-group">
                <?php echo $inap->render(); ?>

            </div>
        </div> -->
        <div class="box-body table-responsive no-padding">
        <div>
        <?php echo $inap->render(); ?>    
        </div>
        
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    <th>No</th>
                    <th>No Pemesanan</th>
                    <th>Nama</th>
                    <th>No Identitas</th>
                    <th>Alamat</th>
                    <th>No Telpon</th>
                    <th style="min-width: 320px;width: 320px"></th>
                </tr>
                <?php $no = 1 ; ?>
                <?php $__empty_1 = true; foreach($inap as $key => $u): $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->nopesanan; ?></td>
                        <td><?php echo $u->namapesanan; ?></td>
                        <td><?php echo $u->noidentitas; ?></td>
                        <td><?php echo $u->alamat; ?></td>
                        <td><?php echo $u->notelp; ?></td>
                        <td>
                            <a href="<?php echo e(url('inapkamar/detail', ['id' => $u->id])); ?>" class="btn btn-flat btn-sm btn-success"><i class="fa fa-edit"></i> Details</a>
                            <a href="<?php echo e(url('inapkamar/bayar', ['id' => $u->id])); ?>" class="btn btn-flat btn-sm btn-info"><i class="fa fa-edit"></i> Bayar</a>
                            <a href="<?php echo e(url('inapkamar/tambahdetail', ['id' => $u->id])); ?>" class="btn btn-flat btn-sm btn-warning"><i class="fa fa-plus"></i> Tambah</a>
                            <a href="<?php echo e(url('inapkamar/hapus', ['id' => $u->id])); ?>" class="btn btn-flat btn-sm btn-danger"><i class="fa fa-warning"></i> Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="9">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>