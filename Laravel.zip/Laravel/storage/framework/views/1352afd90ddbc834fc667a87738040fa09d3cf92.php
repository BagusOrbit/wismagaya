<div class="box box-primary">
    <div class="box-body">
    <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        

        <div class="form-group">
            <?php echo Form::label('namatyperoom', 'Tipe Kamar', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('namatyperoom', null, ['class' => 'form-control', 'placeholder' => 'Nama Tipe']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('Harga', 'Harga', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('Harga',null, ['class' => 'form-control', 'placeholder' => 'Harga']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('Fasilitas', 'Fasilitas', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::textarea('Fasilitas', null, ['class' => 'form-control', 'placeholder' => 'Fasilitas']); ?>

            </div>
        </div>
        <div class="form-group">
            <div class="col-md-offset-2 col-md-4">
                <button class="btn btn-flat btn-primary" type="submit">Simpan</button>
                <a href="<?php echo e(url('/typeroom')); ?>" class="btn btn-flat btn-default">Batal</a>
            </div>
        </div>
    </div>
</div>