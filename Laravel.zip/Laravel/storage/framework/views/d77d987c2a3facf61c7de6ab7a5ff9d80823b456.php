<?php $__env->startSection('title'); ?>
<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
Data Ketersediaan Kamar
<div class="pull-right">
    <a href="<?php echo e(url('reservasi/tambah')); ?>" class="btn btn-flat btn-sm btn-primary"><i class="fa fa-plus"></i> Pesan Kamar</a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
        <?php echo Form::open(['class' => 'form-horizontal']); ?>

        <div class="box-body table-responsive">
                <div class="col-md-0" align="right">
                <?php echo Form::label('tglcheckin', 'Cek In', ['class' => 'control-label col-md-2']); ?>

                </div>
                <div class="col-md-3">
                    <?php echo Form::text('tglcheckin', null, ['class' => 'form-control datepicker', 'placeholder' => 'Tgl Cek In',]); ?>

                </div>   
                <div class="col-md-0" align="right">
                <?php echo Form::label('tglcheckout', 'Cek Out', ['class' => 'control-label col-md-2']); ?>

                </div>
                <div class="col-md-3">
                    <?php echo Form::text('tglcheckout', null, ['class' => 'form-control datepicker', 'placeholder' => 'Tgl Cek Out',]); ?>

                </div>    
                <button class="btn btn-flat btn-primary" type="submit">Cek</button>                
        </div>
         <?php echo Form::close(); ?>

         <?php if($awal != ""): ?>
            <h5>Periode <?php echo $awal; ?> s/d <?php echo $akhir; ?></h5>
        <?php endif; ?>
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    
                    <th>No</th>
                    <th>No Kamar / Room</th>
                    <th>Nama Kamar / Room</th>
                    <th>Fasilitas</th>
                    <th>Harga</th>
                </tr>
                <?php $no = 1; ?>
                <?php $__empty_1 = true; foreach($room as $key => $u): $__empty_1 = false; ?>
                    <tr>
                        
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->noroom; ?></td>
                        <td><?php echo $u->namaroom; ?></td>
                        <td><?php echo $u->fasilitas; ?></td>
                        <td><?php echo number_format($u->harga,0); ?></td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="9">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>