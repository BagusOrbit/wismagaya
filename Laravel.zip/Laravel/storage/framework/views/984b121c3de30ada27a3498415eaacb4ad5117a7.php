<?php $__env->startSection('title'); ?>
    Tambah Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo Form::open(['class' => 'form-horizontal']); ?>

    
    <div class="box box-primary">
    <div class="box-body">
    <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>       
        
            <div class="box">
                    <div class="form-group">
                        <?php echo Form::label('nopesanan', 'No Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo $reservasi->nopesanan; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('namapesanan', 'Nama Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo $reservasi->namapesanan; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('noidentitas', 'KTP/SIM', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo $reservasi->noidentitas; ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('alamat', 'alamat', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo $reservasi->alamat; ?>

                        </div>
                    </div>
        <hr>
        <div class="form-group">
            <?php echo Form::label('namatambahan', 'Nama', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('namatambahan', null, ['class' => 'form-control', 'placeholder' => 'Nama Tambahan']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('qty', 'Jumlah', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('qty',null, ['class' => 'form-control', 'placeholder' => 'Jumlah']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('harga', 'Harga', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('harga',null, ['class' => 'form-control', 'placeholder' => 'Harga Satuan']); ?>

            </div>
        </div>
        <div class="form-group">
            <div class="col-md-4">
                <button class="btn btn-flat btn-primary" type="submit">Simpan</button>
                <a href="<?php echo e(url('/inapkamar')); ?>" class="btn btn-flat btn-default">Batal</a>
            </div>
        </div>
        <?php if(count($inaptambahan) > 0): ?>
        <div class="box-body table-responsive no-padding">
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    <th>No</th>
                    <th>Tambahan</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>SubTotal</th>
                    <th style="min-width: 150px;width: 150px"></th>
                    
                </tr>
                <?php $no = 1 ; ?>
                <?php $__empty_1 = true; foreach($inaptambahan as $key => $u): $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->namatambahan; ?></td>
                        <td><?php echo number_format($u->qty,0); ?></td>
                        <td><?php echo number_format($u->harga,0); ?></td>
                        <td><?php echo number_format($u->subtotal,0); ?></td>
                        <td>                        
                        <a href="<?php echo e(url('inapkamar/hapustambahan', ['id' => $u->id])); ?>" class="btn btn-flat btn-sm btn-danger"><i class="fa fa-remove"></i> Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th colspan="4">TOTAL :</th>
                    <th  align="right"> <?php echo number_format($inaptambahan->sum('subtotal'),0); ?></th>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
        <?php endif; ?>
        
        
    </div>
</div>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>