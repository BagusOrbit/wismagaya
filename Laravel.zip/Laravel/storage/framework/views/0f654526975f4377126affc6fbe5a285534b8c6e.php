<?php $__env->startSection('title'); ?> Hapus Data Tipe kamar CPNS <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo Form::model($typeroom, ['class' => 'form-horizontal']); ?>

            <div class="box box-solid box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Apakah yakin menghapus data tipe kamar?</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <?php echo Form::label('namatyperoom', 'Tipe Kamar', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($typeroom->namatyperoom); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('Harga', 'Harga', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($typeroom->Harga); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('Fasilitas', 'Fasilitas', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($typeroom->Fasilitas); ?>

                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-md-offset-2 col-md-10">
                            <button class="btn btn-flat btn-primary" type="submit">Hapus</button>
                            <a href="<?php echo e(url('/typeroom')); ?>" class="btn btn-flat btn-default">Batal</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>