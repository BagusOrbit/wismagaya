<?php $__env->startSection('title'); ?>
<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
Data Tipe Kamar
<div class="pull-right">
        <!-- <button class="btn btn-flat btn-sm btn-primary" id="load-data-asli"><i class="glyphicon glyphicon-leaf"></i> Lihat Data Asli</button> -->
        <a href="<?php echo e(url('typeroom/tambah')); ?>" class="btn btn-flat btn-sm btn-primary"><i class="fa fa-plus"></i> Tambah Tipe Kamar</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
        
        <div class="box-body table-responsive no-padding">
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Fasilitas</th>
                    <th>Harga</th>
                    <th style="min-width: 150px;width: 150px"></th>
                </tr>
                <?php $no = 1 ; ?>
                <?php $__empty_1 = true; foreach($data as $key => $u): $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->namatyperoom; ?></td>
                        <td><?php echo $u->Fasilitas; ?></td>
                        <td><?php echo number_format($u->Harga,0); ?></td>
                        <td>
                            <a href="<?php echo e(url('typeroom/edit', ['id' => $u->idtyperoom])); ?>" class="btn btn-flat btn-sm btn-primary"><i class="fa fa-edit"></i> Edit</a>
                            <a href="<?php echo e(url('typeroom/hapus', ['id' => $u->idtyperoom])); ?>" class="btn btn-flat btn-sm btn-warning"><i class="fa fa-remove"></i> Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="9">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>