<div class="box box-primary">
    <div class="box-body">
    <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>       
        <div class="form-group">

            <?php echo Form::label('nopesanan', 'Nomor', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('nopesanan', null, ['class' => 'form-control', 'placeholder' => 'Nomor Pemesanan']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('namapesanan', 'Nama', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('namapesanan',null, ['class' => 'form-control', 'placeholder' => 'Nama Pemesan']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('alamat', 'Alamat', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::textarea('alamat', null, ['class' => 'form-control', 'placeholder' => 'Alamat']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('notelp', 'Telp/Hp', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('notelp',null, ['class' => 'form-control', 'placeholder' => 'No Telp / Hp']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('noidentitas', 'KTP/SIM', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('noidentitas',null, ['class' => 'form-control', 'placeholder' => 'No KTP / SIM']); ?>

            </div>
        </div>
    
        <div class="form-group">
            <div class="col-md-offset-2 col-md-4">
                <button class="btn btn-flat btn-primary" type="submit">Simpan</button>
                <a href="<?php echo e(url('/reservasi')); ?>" class="btn btn-flat btn-default">Batal</a>
            </div>
        </div>
        <?php if(count($reservasidetail) > 0): ?>
            <div class="box">
        
        <div class="box-body table-responsive no-padding">
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    <th>No</th>
                    <th>No Kamar</th>
                    <th>Tanggal Cek In</th>
                    <th>Tgl Cek Out</th>
                    <th>Jumlah (Hari)</th>
                    
                </tr>
                <?php $no = 1 ; ?>
                <?php $__empty_1 = true; foreach($reservasidetail as $key => $u): $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->noroom; ?></td>
                        <td><?php echo $u->tglcheckin; ?></td>
                        <td><?php echo $u->tglcheckout; ?></td>
                        <td><?php echo $u->Jumlahhari; ?></td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="9">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
        <?php endif; ?>
    </div>
</div>