<?php $__env->startSection('title'); ?> Hapus Data Menginap / Menginap@endsection

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php echo Form::model($inap, ['class' => 'form-horizontal']); ?>

            <div class="box box-solid box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Apakah yakin menghapus data Menginap?</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <div class="form-group">
                        <?php echo Form::label('nopesanan', 'No Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($inap->nopesanan); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('namapesanan', 'Nama Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($inap->namapesanan); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('noidentitas', 'KTP/SIM', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($inap->noidentitas); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('alamat', 'alamat', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($inap->alamat); ?>

                        </div>
                    </div>
                    
                    
                </div>
                <?php if(count($inapdetail) > 0): ?>
        <h3>Data Detail Kamar</h3>
        <div class="box-body table-responsive no-padding">
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    <th>No</th>
                    <th>No Kamar</th>
                    <th>Tanggal Cek In</th>
                    <th>Tgl Cek Out</th>
                    <th>Jumlah (Hari)</th>
                    <th>Sewa Perhari</th>                    
                    <th>SubTotal</th>
                    
                </tr>
                <?php $no = 1 ; ?>
                <?php $__empty_1 = true; foreach($inapdetail as $key => $u): $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->noroom; ?></td>
                        <td><?php echo $u->tglcheckin; ?></td>
                        <td><?php echo $u->tglcheckout; ?></td>
                        <td><?php echo $u->Jumlahhari; ?></td>
                        <td><?php echo number_format($u->sewaperhari,0); ?></td>
                        <td><?php echo number_format($u->subtotal,0); ?></td>
                        
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" >Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th colspan="6">TOTAL :</th>
                    <th  align="right"> <?php echo number_format($inapdetail->sum('subtotal'),0); ?></th>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
        <?php endif; ?>
        <hr>
        <?php if(count($inaptambahan) > 0): ?>
        <h3>Data Tambahan</h3>
        <div class="box-body table-responsive no-padding">
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    <th>No</th>
                    <th>Tambahan</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>SubTotal</th>
                    
                </tr>
                <?php $no = 1 ; ?>
                <?php $__empty_1 = true; foreach($inaptambahan as $key => $u): $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->namatambahan; ?></td>
                        <td><?php echo number_format($u->qty,0); ?></td>
                        <td><?php echo number_format($u->harga,0); ?></td>
                        <td><?php echo number_format($u->subtotal,0); ?></td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th colspan="5">TOTAL :</th>
                    <th  align="right"> <?php echo number_format($inaptambahan->sum('subtotal'),0); ?></th>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
        <?php endif; ?>
                <div class="form-group">
                    <div class="col-md-10">
                        <button class="btn btn-flat btn-primary" type="submit">Hapus</button>
                        <a href="<?php echo e(url('/inapkamar')); ?>" class="btn btn-flat btn-default">Batal</a>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>