<div class="box box-primary">
    <div class="box-body">
    <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>       
        
            <div class="box">
                    <div class="form-group">
                        <?php echo Form::label('nopesanan', 'No Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->nopesanan); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('namapesanan', 'Nama Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->namapesanan); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('noidentitas', 'KTP/SIM', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->noidentitas); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('alamat', 'alamat', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->alamat); ?>

                        </div>
                    </div>
        <hr>
        
            
        <?php if(count($reservasidetail) > 0): ?>
        <div class="box-body table-responsive no-padding">
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    <th>No</th>
                    <th>No Kamar</th>
                    <th>Tanggal Cek In</th>
                    <th>Tgl Cek Out</th>
                    <th>Jumlah (Hari)</th>
                    <th>Sewa Perhari</th>                    
                    <th>SubTotal</th>
                </tr>
                <?php $no = 1 ; ?>
                <?php $__empty_1 = true; foreach($reservasidetail as $key => $u): $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->noroom; ?></td>
                        <td><?php echo $u->tglcheckin; ?></td>
                        <td><?php echo $u->tglcheckout; ?></td>
                        <td><?php echo $u->Jumlahhari; ?></td>
                        <td><?php echo number_format($u->sewaperhari,0); ?></td>
                        <td><?php echo number_format($u->subtotal,0); ?></td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" >Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <th colspan="6">TOTAL :</th>
                    <th  align="right"> <?php echo number_format($reservasidetail->sum('subtotal'),0); ?></th>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
        <?php endif; ?>
       <?php
        $pajak = (($reservasidetail->sum('subtotal') * 10) / 100);

        $totalsemua = $reservasidetail->sum('subtotal') + $pajak;
        // dd($totalsemua);
        // exit();
       ?>
         <div class="form-group">
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
                <?php echo Form::label('pajaknominal', 'Pajak', ['class' => 'control-label col-md-2']); ?>

                <div class="col-md-10">
                <?php echo Form::text('pajaknominal',$pajak, ['class' => 'form-control']); ?>

                </div>
            </div>
            
            
        </div>
        <div class="form-group">
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
                <?php echo Form::label('potongannominal', 'Pot', ['class' => 'control-label col-md-2']); ?>

                <div class="col-md-10">
                <?php echo Form::text('potongannominal',0, ['class' => 'form-control']); ?>

                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
                <?php echo Form::label('biayalain', 'Biaya', ['class' => 'control-label col-md-2']); ?>

                <div class="col-md-10">
                <?php echo Form::text('biayalain',0, ['class' => 'form-control']); ?>

                </div>
            </div>            
        </div>
        <div class="form-group">
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
                <!-- <?php echo Form::label('totalakhir', 'T.Akhir', ['class' => 'control-label col-md-2']); ?> -->
                <div class="col-md-10">
                
                <!-- <?php echo Form::text('totalsemua',null, ['class' => 'form-control']); ?> -->
                </div>
            </div>            
        </div>

        <div class="form-group">
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
            </div>
            
            <div class="col-md-4">
                <?php echo Form::label('totalsemua', 'T.Akhir', ['class' => 'control-label col-md-2']); ?>

                <div class="col-md-10">
                <?php echo Form::hidden('totalakhir',$reservasidetail->sum('subtotal'), ['class' => 'form-control']); ?>

                <?php echo Form::text('totalsemua',$totalsemua, ['class' => 'form-control','readonly' => 'readonly']); ?>

                </div>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
            </div>
            
            <div class="col-md-4">
                <?php echo Form::label('dp', 'DP', ['class' => 'control-label col-md-2']); ?>

                <div class="col-md-10">
                <?php echo Form::text('dp',0, ['class' => 'form-control']); ?>

                </div>
            </div>
        </div>
        

        <div class="form-group">
            <div class="col-md-4">
                <button class="btn btn-flat btn-primary" type="submit">Menginap</button>
                <a href="<?php echo e(url('/reservasi')); ?>" class="btn btn-flat btn-default">Batal</a>
            </div>
        </div>
    </div>
</div>
