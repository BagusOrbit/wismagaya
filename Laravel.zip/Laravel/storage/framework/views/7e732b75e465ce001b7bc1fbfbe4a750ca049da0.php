<div class="box box-primary">
    <div class="box-body">
    <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>       
        
            <div class="box">
                    <div class="form-group">
                        <?php echo Form::label('nopesanan', 'No Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->nopesanan); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('namapesanan', 'Nama Pemesanan', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->namapesanan); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('noidentitas', 'KTP/SIM', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->noidentitas); ?>

                        </div>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('alamat', 'alamat', ['class' => 'control-label col-md-2']); ?>

                        <div class="col-md-8 form-control-static">
                            <?php echo e($reservasi->alamat); ?>

                        </div>
                    </div>
        <hr>
        <hr>
        

        <div class="form-group">

            <?php echo Form::label('tglcheckin', 'Tgl Cek In', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('tglcheckin', null, ['class' => 'form-control datepicker', 'placeholder' => 'Tgl Cek In',]); ?>

            </div>
            <?php echo Form::label('tglcheckout', 'Tgl Cek Out', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('tglcheckout', null, ['class' => 'form-control datepicker', 'placeholder' => 'Tgl Cek Out',]); ?>

            </div>
        </div>
        
        <div class="form-group">
            <?php echo Form::label('idroom', 'Kamar', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::select('idroom', $room,null, ['class' => 'form-control', 'placeholder' => 'Kamar','id' => 'state']); ?>

            </div>
            <?php echo Form::label('Jumlahhari', 'Hari', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('Jumlahhari',null, ['class' => 'form-control', 'placeholder' => 'Jumlah Hari']); ?>

            </div>
        
        </div>
    
        <div class="form-group">
            <div class="col-md-offset-2 col-md-4">
                <button class="btn btn-flat btn-primary" type="submit">Simpan</button>
                <a href="<?php echo e(url('/reservasi')); ?>" class="btn btn-flat btn-default">Batal</a>
            </div>
        </div>
        <?php if(count($reservasidetail) > 0): ?>
        <div class="box-body table-responsive no-padding">
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    <th>No</th>
                    <th>No Kamar</th>
                    <th>Tanggal Cek In</th>
                    <th>Tgl Cek Out</th>
                    <th>Jumlah (Hari)</th>
                    <th style="min-width: 150px;width: 150px"></th>
                    
                </tr>
                <?php $no = 1 ; ?>
                <?php $__empty_1 = true; foreach($reservasidetail as $key => $u): $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->noroom; ?></td>
                        <td><?php echo $u->tglcheckin; ?></td>
                        <td><?php echo $u->tglcheckout; ?></td>
                        <td><?php echo $u->Jumlahhari; ?></td>
                        <td>                        
                        <a href="<?php echo e(url('reservasidetail/hapus', ['id' => $u->idpemesanandetail])); ?>" class="btn btn-flat btn-sm btn-danger"><i class="fa fa-remove"></i> Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="9">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
        <?php endif; ?>
    </div>
</div>