<div class="box box-primary">
    <div class="box-body">
    <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="form-group">
            <?php echo Form::label('tanggal', 'Tanggal', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('tanggal', null, ['class' => 'form-control datepicker', 'placeholder' => 'Tanggal',]); ?>

            </div>
        </div>
        
        <div class="form-group">
            <?php echo Form::label('itembiayaid', 'Biaya', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::select('itembiayaid', $itembiaya,null, ['class' => 'form-control', 'placeholder' => 'Biaya','id' => 'state']); ?>

            </div>
        </div>
        <div class="form-group">
            <?php echo Form::label('nominal', 'Nominal', ['class' => 'control-label col-md-2']); ?>

            <div class="col-md-4">
                <?php echo Form::text('nominal',null, ['class' => 'form-control', 'placeholder' => 'Nominal']); ?>

            </div>
        </div>
        
        <div class="form-group">
            <div class="col-md-offset-2 col-md-4">
                <button class="btn btn-flat btn-primary" type="submit">Simpan</button>
                <a href="<?php echo e(url('/biaya')); ?>" class="btn btn-flat btn-default">Batal</a>
            </div>
        </div>
    </div>
</div>
