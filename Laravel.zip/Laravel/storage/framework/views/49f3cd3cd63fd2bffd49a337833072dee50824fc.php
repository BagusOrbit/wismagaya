<?php $__env->startSection('title'); ?>
<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
Data Pemesanan Kamar
<div class="pull-right">
        <a href="<?php echo e(url('cekkamar')); ?>" class="btn btn-flat btn-sm btn-success"><i class="glyphicon glyphicon-leaf"></i> Cek Kamar</a>
        <a href="<?php echo e(url('reservasi/tambah')); ?>" class="btn btn-flat btn-sm btn-primary"><i class="fa fa-plus"></i> Tambah Pemesanan Kamar</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box">
        
        <div class="box-body table-responsive no-padding">
            <table class="table table-condensed table-bordered table-hover table-striped">
                <tbody>
                <tr>
                    <th>No</th>
                    <th>No Pemesanan</th>
                    <th>Nama</th>
                    <th>No Identitas</th>
                    <th>Alamat</th>
                    <th>No Telpon</th>
                    <th style="min-width: 300px;width: 300px"></th>
                </tr>
                <?php $no = 1 ; ?>
                <?php $__empty_1 = true; foreach($reservasi as $key => $u): $__empty_1 = false; ?>

                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $u->nopesanan; ?></td>
                        <td><?php echo $u->namapesanan; ?></td>
                        <td><?php echo $u->noidentitas; ?></td>
                        <td><?php echo $u->alamat; ?></td>
                        <td><?php echo $u->notelp; ?></td>
                        <td>
                            <a href="<?php echo e(url('reservasi/edit', ['id' => $u->id])); ?>" class="btn btn-flat btn-sm btn-primary"><i class="fa fa-edit"></i> Edit</a>
                            <a href="<?php echo e(url('reservasidetail/tambah', ['id' => $u->id])); ?>" class="btn btn-flat btn-sm btn-info"><i class="fa fa-edit"></i> Detail</a>
                            <a href="<?php echo e(url('inapkamar/tambah', ['id' => $u->id])); ?>" class="btn btn-flat btn-sm btn-warning"><i class="fa fa-plus"></i> Inap</a>
                            <a href="<?php echo e(url('reservasi/hapus', ['id' => $u->id])); ?>" class="btn btn-flat btn-sm btn-danger"><i class="fa fa-remove"></i> Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; if ($__empty_1): ?>
                    <tr>
                        <td colspan="9">Tidak ada data</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>